gcloud info
