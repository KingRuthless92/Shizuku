tightvncserver -version
:
