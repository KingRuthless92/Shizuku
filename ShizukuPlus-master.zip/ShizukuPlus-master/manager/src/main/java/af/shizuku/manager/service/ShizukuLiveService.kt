package af.shizuku.manager.service

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import timber.log.Timber
import af.shizuku.manager.utils.LiveActivityNotificationManager
import af.shizuku.manager.utils.ShizukuStateMachine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect

class ShizukuLiveService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        private const val TAG = "ShizukuLiveService"
    }

    override fun onCreate() {
        super.onCreate()

        serviceScope.launch {
            ShizukuStateMachine.asFlow().collect { state ->
                val isRunning = state == ShizukuStateMachine.State.RUNNING
                if (isRunning) {
                    val notif = LiveActivityNotificationManager.buildNotification(
                        this@ShizukuLiveService, "System Bridge Active"
                    )
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                            startForeground(LiveActivityNotificationManager.NOTIFICATION_ID, notif,
                                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                        } else {
                            startForeground(LiveActivityNotificationManager.NOTIFICATION_ID, notif)
                        }
                    } catch (e: Throwable) {
                        Timber.tag(TAG).w(e, "startForeground refused on state update")
                    }
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                    } else {
                        @Suppress("DEPRECATION")
                        stopForeground(true)
                    }
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForeground() must be called within 5s of startForegroundService().
        // Use current state for the initial notification; the flow in onCreate() will keep it updated.
        val isRunning = ShizukuStateMachine.get() == ShizukuStateMachine.State.RUNNING
        val notif = LiveActivityNotificationManager.buildNotification(
            this, if (isRunning) "System Bridge Active" else "Monitoring..."
        )
        if (!startForegroundSafely(notif)) {
            stopSelf()
            return START_NOT_STICKY
        }
        // If not running, remove the foreground notification immediately — service stays alive silently.
        if (!isRunning) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
        return START_STICKY
    }

    // Returns false when the platform refuses the FGS notification (CannotPostForegroundService-
    // NotificationException, ForegroundServiceStartNotAllowedException, etc.) so callers can
    // stopSelf() gracefully rather than crashing — SHIZUKUPLUS-5P.
    private fun startForegroundSafely(notif: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(LiveActivityNotificationManager.NOTIFICATION_ID, notif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(LiveActivityNotificationManager.NOTIFICATION_ID, notif)
            }
            true
        } catch (e: Throwable) {
            Timber.tag(TAG).w(e, "startForeground refused; stopping service")
            false
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        LiveActivityNotificationManager.dismiss(this)
        super.onDestroy()
    }
}
