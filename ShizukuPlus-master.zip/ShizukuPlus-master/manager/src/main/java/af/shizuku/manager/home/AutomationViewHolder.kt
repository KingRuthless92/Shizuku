package af.shizuku.manager.home

import android.os.Build
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.textfield.TextInputEditText
import af.shizuku.manager.BuildConfig
import af.shizuku.manager.R
import af.shizuku.manager.ShizukuSettings
import af.shizuku.manager.databinding.HomeAutomationBinding
import af.shizuku.manager.databinding.HomeAutomationBottomSheetBinding
import af.shizuku.manager.databinding.HomeItemContainerBinding
import af.shizuku.manager.ktx.toHtml
import af.shizuku.manager.utils.EnvironmentUtils
import af.shizuku.manager.utils.IconStyleHelper
import af.shizuku.manager.utils.MotionUtils.applySpringTouch
import rikka.core.util.ClipboardUtils
import rikka.html.text.HtmlCompat
import rikka.recyclerview.BaseViewHolder
import rikka.recyclerview.BaseViewHolder.Creator

class AutomationViewHolder(
    private val binding: HomeAutomationBinding,
    private val containerBinding: HomeItemContainerBinding,
) : BaseViewHolder<Any?>(containerBinding.root) {
    companion object {
        val CREATOR =
            Creator<Any> { inflater: LayoutInflater, parent: ViewGroup? ->
                val outer = HomeItemContainerBinding.inflate(inflater, parent, false)
                val inner = HomeAutomationBinding.inflate(inflater, outer.cardContent, true)
                AutomationViewHolder(inner, outer)
            }
    }

    private data class Field(
        val layout: TextInputLayout,
        val input: TextInputEditText,
        val initText: String
    )

    private val originalIcon = binding.icon.drawable

    init {
        containerBinding.root.applySpringTouch()
        containerBinding.root.setOnLongClickListener { HomeEditMode.enter(); true }
        containerBinding.dragHandle.apply {
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_DOWN) HomeEditMode.startDragCallback?.invoke(this@AutomationViewHolder)
                false
            }
            setOnLongClickListener { HomeEditMode.enter(); true }
        }
        binding.button1.setOnClickListener { v ->
            val context = v.context
            val authToken = af.shizuku.manager.ShizukuSettings.getAuthToken()
            val encryptedToken = af.shizuku.manager.utils.IntentCrypto.encrypt(authToken)
            // If AndroidKeyStore is unavailable (restricted OEMs such as Vivo), fall back to the
            // raw plaintext token.  AuthenticatedReceiver / ShellRequestHandlerActivity already
            // accept both encrypted (bare base64) and raw-plaintext values via constant-time
            // MessageDigest comparison, so this graceful degradation is safe.
            if (encryptedToken == null) {
                Toast.makeText(context, R.string.home_automation_token_encrypt_failed, Toast.LENGTH_SHORT).show()
            }

            val sheetBinding = HomeAutomationBottomSheetBinding.inflate(
                LayoutInflater.from(context)
            )

            // The extrasLayout already has app:prefixText="auth: " in the layout XML, so we do NOT
            // add the "auth:" prefix to the EditText value here — doing so would double-prefix the
            // visible text (users see "auth:  auth:<base64>") and, more critically, the copied
            // value "auth:<base64>" would survive the "auth:" stripping in AuthenticatedReceiver
            // but leave "auth:<base64>" fed into Base64.decode(), which fails on the ":"  character
            // — meaning every encrypted token silently falls back to a plaintext comparison that
            // can never match (base64 ≠ raw token), producing "Invalid auth token" (#467).
            //
            // Showing just the base64 (or raw token) in the field keeps the visual display correct
            // (prefix "auth: " + base64 body) and makes the copied value exactly what
            // AuthenticatedReceiver / ShellRequestHandlerActivity / BinderRequestReceiver expect:
            // either a bare base64 blob that decrypts to the stored token, or the raw plaintext
            // token on devices where AndroidKeyStore is unavailable.
            val extrasValue = encryptedToken ?: authToken

            sheetBinding.apply {
                val action = getIntentAction(buttonGroup.checkedButtonId)
                val fields = listOf(
                    Field(actionLayout, actionEditText, action),
                    Field(packageLayout, packageEditText, context.packageName),
                    Field(targetLayout, targetEditText, "Broadcast Receiver"),
                    Field(extrasLayout, extrasEditText, extrasValue)
                )

                fields.forEach { (layout, input, initText) ->
                    input.setText(initText)
                    input.setKeyListener(null)

                    layout.setEndIconOnClickListener { v ->
                        val context = v.context
                        if (
                            ClipboardUtils.put(context, input.text) &&
                            Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2
                        ) {
                            Toast.makeText(
                                context,
                                context.getString(R.string.toast_copied_to_clipboard),
                                Toast.LENGTH_SHORT,
                            ).show()
                        }
                    }
                }

                buttonGroup.addOnButtonCheckedListener { _, buttonId, isChecked ->
                    if (isChecked) {
                        val action = getIntentAction(buttonId)
                        actionEditText.setText(action)
                    }
                }
                extrasLayout.setStartIconOnClickListener {
                    MaterialAlertDialogBuilder(context)
                        .setTitle(R.string.home_automation_regenerate_token)
                        .setMessage(R.string.home_automation_regenerate_token_message)
                        .setNegativeButton(android.R.string.cancel, null)
                        .setPositiveButton(android.R.string.ok, { _, _ ->
                            val newToken = ShizukuSettings.generateAuthToken()
                            val newEncryptedToken = af.shizuku.manager.utils.IntentCrypto.encrypt(newToken)
                            if (newEncryptedToken == null) {
                                // AndroidKeyStore unavailable: show a warning but still populate the
                                // field with the raw token so the automation can be saved and used.
                                Toast.makeText(context, R.string.home_automation_token_encrypt_failed, Toast.LENGTH_SHORT).show()
                                extrasEditText.setText(newToken)
                            } else {
                                // As with the initial display, set only the base64 body — the
                                // extrasLayout prefixText already supplies the visual "auth: " label.
                                extrasEditText.setText(newEncryptedToken)
                            }
                        })
                        .show()
                }
            }

            BottomSheetDialog(context).apply {
                setContentView(sheetBinding.root)
                show()
            }
        }

        if (
            Build.VERSION.SDK_INT < Build.VERSION_CODES.R &&
            !EnvironmentUtils.isTelevision() &&
            !EnvironmentUtils.isRooted()
        ) {
            binding.text2.apply {
                isVisible = true
                text = context.getString(R.string.home_automation_description_device_restriction, "adb tcpip 5555")
                    .toHtml(HtmlCompat.FROM_HTML_OPTION_TRIM_WHITESPACE)
            }
        }
    }

    override fun onBind() {
        HomeEditMode.applyOverlay(containerBinding)
        IconStyleHelper.applyToCardIcon(binding.icon, originalIcon, "home_automation")
    }

    private fun getIntentAction(buttonId: Int): String =
        when (buttonId) {
            R.id.buttonStart -> "${BuildConfig.APPLICATION_ID}.START"
            R.id.buttonStop -> "${BuildConfig.APPLICATION_ID}.STOP"
            else -> ""
        }
}
