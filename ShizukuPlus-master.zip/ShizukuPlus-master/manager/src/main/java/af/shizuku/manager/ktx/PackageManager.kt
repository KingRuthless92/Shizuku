package af.shizuku.manager.ktx

import android.content.ComponentName
import android.content.pm.PackageManager

fun PackageManager.setComponentEnabled(componentName: ComponentName, enabled: Boolean) {
    val oldState = getComponentEnabledSetting(componentName)
    val newState = if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    if (newState != oldState) {
        val flags = PackageManager.DONT_KILL_APP
        setComponentEnabledSetting(componentName, newState, flags)
    }
}

