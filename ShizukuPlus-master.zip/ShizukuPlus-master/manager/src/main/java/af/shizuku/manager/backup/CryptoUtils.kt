package af.shizuku.manager.backup

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object CryptoUtils {

    // The auth-required alias is versioned (_v2): keys created before the device-credential fix
    // (#332/#315) were biometric-only, so a password/PIN-locked device could pass canAuthenticate,
    // authenticate with its credential, yet the credential couldn't unlock the biometric-only key -
    // surfacing as IllegalBlockSizeException("Key user not authenticated") at doFinal. Those old
    // keys can't be "upgraded" in place, so v2 forces a fresh, device-credential-capable key for
    // everyone. Cost: auth-protected backups made before this fix can't be restored (re-create
    // them); acceptable since that path was largely broken on non-biometric devices anyway.
    private const val KEY_ALIAS_AUTH = "ShizukuPlusBackupKey_v2"
    private const val KEY_ALIAS_NO_AUTH = "ShizukuPlusBackupKey_no_auth"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val TRANSFORMATION = "${KeyProperties.KEY_ALGORITHM_AES}/${KeyProperties.BLOCK_MODE_GCM}/${KeyProperties.ENCRYPTION_PADDING_NONE}"

    private fun keyAlias(userAuthRequired: Boolean) = if (userAuthRequired) KEY_ALIAS_AUTH else KEY_ALIAS_NO_AUTH

    fun getOrCreateSecretKey(userAuthRequired: Boolean): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
        keyStore.load(null)

        val alias = keyAlias(userAuthRequired)

        try {
            if (keyStore.containsAlias(alias)) {
                val key = keyStore.getKey(alias, null) as? SecretKey
                if (key != null) return key
            }
        } catch (_: Exception) {
            try { keyStore.deleteEntry(alias) } catch (_: Exception) {}
        }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val builder = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            
        if (userAuthRequired) {
            builder.setUserAuthenticationRequired(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                // Accept EITHER a biometric or the device credential (PIN/pattern/password), matching
                // what BiometricLock allows. Without this the key defaults to biometric-only, so a
                // password-locked device with no biometric enrolled can never unlock it (#315/#332).
                // Timeout 0 = authenticate per use, keeping the existing CryptoObject flow intact.
                builder.setUserAuthenticationParameters(
                    0,
                    KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL
                )
            }
            // Pre-R keeps the legacy biometric-only CryptoObject binding (BiometricLock already
            // forces BIOMETRIC_STRONG when a CryptoObject is passed below API 30).
        }

        keyGenerator.init(builder.build())
        return keyGenerator.generateKey()
    }

    private fun deleteKey(userAuthRequired: Boolean) {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
            keyStore.load(null)
            keyStore.deleteEntry(keyAlias(userAuthRequired))
        } catch (_: Exception) {}
    }

    fun getCipherForEncryption(userAuthRequired: Boolean): Cipher {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        try {
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey(userAuthRequired))
        } catch (_: KeyPermanentlyInvalidatedException) {
            // Android invalidates the key by design when the device's biometrics/screen-lock
            // change (#332). Safe to regenerate here since we're encrypting a brand-new backup,
            // not trying to decrypt existing ciphertext tied to the old key material.
            deleteKey(userAuthRequired)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey(userAuthRequired))
        }
        return cipher
    }

    private fun keyExists(userAuthRequired: Boolean): Boolean = try {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
        keyStore.load(null)
        keyStore.containsAlias(keyAlias(userAuthRequired))
    } catch (_: Exception) {
        false
    }

    fun getCipherForDecryption(iv: ByteArray, userAuthRequired: Boolean): Cipher {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        val spec = GCMParameterSpec(128, iv)
        // If the key alias is gone (the app was uninstalled/reinstalled, or its data was cleared),
        // getOrCreateSecretKey would silently MINT A BRAND-NEW key. Decryption would then fail deep
        // inside doFinal() with an opaque AEADBadTagException AND leave a useless orphan key behind
        // (#370). Detect the missing key up front and throw a clear, catchable error instead: a
        // hardware-backed keystore key is non-exportable and destroyed on uninstall, so a backup can
        // genuinely only be restored by the same installation that made it.
        if (!keyExists(userAuthRequired)) {
            throw BackupKeyUnavailableException()
        }
        // No auto-regeneration here: an invalidated key's material is gone for good, so a fresh
        // key could never decrypt ciphertext written under the old one. Let it throw - the
        // caller shows KeyPermanentlyInvalidatedException with a message explaining the backup
        // is unrecoverable, rather than silently producing a cipher that can't decrypt anything.
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(userAuthRequired), spec)
        return cipher
    }
}

/**
 * Thrown when a settings backup can't be decrypted because its AndroidKeyStore key no longer exists
 * on this device (typically after uninstall/reinstall or clearing app data). Distinct from
 * AEADBadTagException so the UI can explain the real cause rather than showing a raw crypto error.
 */
class BackupKeyUnavailableException : java.security.GeneralSecurityException(
    "The encryption key for this backup no longer exists on this device. Settings backups are " +
        "encrypted with a hardware-backed key that is destroyed when Shizuku+ is uninstalled or its " +
        "data is cleared, so a backup can only be restored by the installation that created it."
)
