package af.shizuku.manager.utils

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.ActivityResultLauncher
import android.os.PowerManager
import android.provider.Settings
import af.shizuku.manager.R
import af.shizuku.manager.utils.SettingsPage

object SettingsHelper {

    fun launchOrHighlightWirelessDebugging(context: Context) {
        if (EnvironmentUtils.isAdbEnabled()) {
            SettingsPage.Developer.WirelessDebugging.launch(context)
        } else SettingsPage.Developer.HighlightWirelessDebugging.launch(context)
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun hasWriteSecureSettings(context: Context): Boolean {
        return context.checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    fun promptWriteSecureSettings(context: Context) {
        if (hasWriteSecureSettings(context)) {
            android.widget.Toast.makeText(context, R.string.accessibility_permission_granted, android.widget.Toast.LENGTH_SHORT).show()
            return
        }

        // 1. Automatic grant via Shizuku if service is alive
        if (rikka.shizuku.Shizuku.pingBinder()) {
            try {
                val p = rikka.shizuku.Shizuku.newProcess(
                    arrayOf("pm", "grant", context.packageName, "android.permission.WRITE_SECURE_SETTINGS"),
                    null,
                    null
                )
                if (p != null) {
                    try {
                        if (p.waitFor() == 0 && hasWriteSecureSettings(context)) {
                            android.widget.Toast.makeText(context, R.string.accessibility_permission_granted, android.widget.Toast.LENGTH_SHORT).show()
                            return
                        }
                    } finally {
                        try { p.destroy() } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                timber.log.Timber.w(e, "Auto-grant WRITE_SECURE_SETTINGS via Shizuku failed")
            }
        }

        // 2. Automatic grant via Root if available
        if (EnvironmentUtils.isRooted()) {
            try {
                val res = com.topjohnwu.superuser.Shell.cmd("pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS").exec()
                if (res.isSuccess && hasWriteSecureSettings(context)) {
                    android.widget.Toast.makeText(context, R.string.accessibility_permission_granted, android.widget.Toast.LENGTH_SHORT).show()
                    return
                }
            } catch (e: Exception) {
                timber.log.Timber.w(e, "Auto-grant WRITE_SECURE_SETTINGS via Root failed")
            }
        }

        // 3. Fallback: manual copy command dialog
        val command = "adb shell pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS"
        com.google.android.material.dialog.MaterialAlertDialogBuilder(context)
            .setTitle(R.string.wadb_permission_error_notification_title)
            .setMessage(context.getString(R.string.dialog_adb_pairing_accessibility_permission, "WRITE_SECURE_SETTINGS", command))
            .setPositiveButton(R.string.home_adb_dialog_view_command_copy_button) { _, _ ->
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("adb command", command))
                android.widget.Toast.makeText(context, R.string.toast_copied_to_clipboard, android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    fun isAccessibilityServiceEnabled(context: Context, serviceClass: Class<*>): Boolean {
        val expectedComponent = ComponentName(context, serviceClass).flattenToString()
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expectedComponent, ignoreCase = true) }
    }

    fun requestIgnoreBatteryOptimizations(context: Context, launcher: ActivityResultLauncher<Intent>? = null) {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            setData(Uri.parse("package:" + context.packageName))
        }
        try {
            launcher?.launch(intent) ?: context.startActivity(intent)
        } catch (_: IllegalStateException) {
            // Launcher may be unregistered if the fragment was detached — fall back to startActivity
            context.startActivity(intent)
        }
    }

    fun isSamsungAutoBlockerDisabled(context: Context): Boolean {
        return try {
            val rampart = Settings.Secure.getInt(context.contentResolver, "rampart_enabled", 0)
            rampart == 0
        } catch (_: Exception) {
            true
        }
    }

    fun isSamsungMaxRestrictionsDisabled(context: Context): Boolean {
        return try {
            val maxRestrictions = Settings.Secure.getInt(context.contentResolver, "rampart_max_restrictions_enabled", 0)
            maxRestrictions == 0
        } catch (_: Exception) {
            true
        }
    }
}
