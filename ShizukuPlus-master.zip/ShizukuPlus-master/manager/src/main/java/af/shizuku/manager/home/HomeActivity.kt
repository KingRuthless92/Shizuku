package af.shizuku.manager.home

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.method.LinkMovementMethod
import timber.log.Timber
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.airbnb.mvrx.MavericksView
import com.airbnb.mvrx.viewModel
import com.airbnb.mvrx.withState
import com.airbnb.mvrx.Success
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import af.shizuku.manager.R
import af.shizuku.manager.ShizukuSettings
import af.shizuku.manager.adb.AdbPairingService
import af.shizuku.manager.worker.AdbStartWorker
import af.shizuku.manager.app.SnackbarHelper
import af.shizuku.manager.home.showAccessibilityDialog
import af.shizuku.manager.ktx.toHtml
import af.shizuku.manager.management.AppsViewModel
import af.shizuku.manager.settings.SettingsActivity
import af.shizuku.manager.update.UpdateChecker
import af.shizuku.manager.update.UpdateManager
import af.shizuku.manager.utils.EnvironmentUtils
import io.noties.markwon.Markwon
import af.shizuku.manager.utils.HapticUtils
import af.shizuku.manager.utils.SettingsHelper
import af.shizuku.manager.utils.SettingsPage
import af.shizuku.manager.utils.ShizukuStateMachine
import rikka.core.ktx.unsafeLazy
import rikka.lifecycle.Status
import rikka.recyclerview.addEdgeSpacing
import rikka.recyclerview.addItemSpacing
import rikka.recyclerview.fixEdgeEffect
import rikka.shizuku.Shizuku

import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import af.shizuku.core.ui.AppActivity
import af.shizuku.manager.home.compose.HomeScreen

open class HomeActivity : AppActivity(), MavericksView {

    private val homeModel: HomeViewModel by viewModel()
    private val appsModel: AppsViewModel by viewModels()
    private val adapter by unsafeLazy { HomeAdapter(homeModel, appsModel, lifecycleScope) }
    private var activeUpdateManager: UpdateManager? = null

    // Registered unconditionally (required before onStart); only invoked on API 33+. The
    // shell-consent notification (#377) silently no-ops without this permission, reproducing
    // the original BAL timeout with no visible cause - request it once here so every user gets
    // asked regardless of which flow (root/ADB/PC) they use to start the service.
    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Nothing to do either way: system handles permanently-denied dialog suppression. */ }

    // Removed getLayoutId

    // Show the "restart after update" prompt at most once per Activity instance so it doesn't
    // reappear on every state refresh while the user hasn't restarted yet.
    private var versionSkewSnackbarShown = false
    // Same once-per-session guard for the Samsung Auto Blocker hint snackbar.
    private var autoBlockerSnackbarShown = false

    // Tracks the service's running state across successive serviceStatus updates so the
    // "just started" celebratory animation below can detect a real transition. Must be a plain
    // field, not read back from homeModel's state inside the same onEach callback that just
    // committed the new status — by then withState() would already see the *new* value, not
    // the one before this particular update. Null until the first Success is observed, so the
    // animation doesn't fire on cold start just because the service happened to already be running.
    private var wasServiceRunning: Boolean? = null

    // Guard: attempt auto-restart at most once per Activity instance. Prevents re-trying on
    // every subsequent resume/status-refresh if the first attempt doesn't produce a running binder
    // quickly enough (which would create a WorkManager queue pile-up).
    private var autoRestartAttempted = false

    // Compose state at class level so onResume() and appearanceChangeListener can update it
    // without being in onCreate()'s closure scope.
    private var isOneHanded by mutableStateOf(ShizukuSettings.isOneHandedModeEnabled())
    private var isOneUi by mutableStateOf(ShizukuSettings.isOneUiThemeEnabled())
    private var isRoundedEdges by mutableStateOf(ShizukuSettings.isRoundedEdgesEnabled())

    // Strong reference required — SharedPreferences holds listeners weakly, so an inline lambda
    // would be eligible for GC immediately after registerOnSharedPreferenceChangeListener returns.
    private val appearanceChangeListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            ShizukuSettings.Keys.KEY_ICON_STYLE,
            ShizukuSettings.Keys.KEY_ICON_COLOR_MODE,
            ShizukuSettings.Keys.KEY_SHAPE_STYLE,
            ShizukuSettings.Keys.KEY_ROUNDED_EDGES,
            ShizukuSettings.Keys.KEY_EXPRESSIVE_SHAPES -> {
                isRoundedEdges = ShizukuSettings.isRoundedEdgesEnabled()
                adapter.notifyDataSetChanged()
            }
            ShizukuSettings.Keys.KEY_SHOW_TERMINAL_HOME,
            ShizukuSettings.Keys.KEY_SHOW_AUTOMATION_HOME,
            ShizukuSettings.Keys.KEY_SHOW_LEARN_MORE_HOME,
            ShizukuSettings.Keys.KEY_SHOW_ACTIVITY_LOG_HOME,
            ShizukuSettings.Keys.KEY_SHOW_START_ADB_HOME,
            ShizukuSettings.Keys.KEY_SHOW_BACKUP_HOME -> adapter.updateData()
            ShizukuSettings.Keys.KEY_ONE_HANDED_MODE,
            ShizukuSettings.Keys.KEY_ONEUI_THEME -> {
                isOneHanded = ShizukuSettings.isOneHandedModeEnabled()
                isOneUi = ShizukuSettings.isOneUiThemeEnabled()
            }
        }
    }

    private val stateListener: (ShizukuStateMachine.State) -> Unit = { state ->
        when (state) {
            ShizukuStateMachine.State.RUNNING -> {
                // Shizuku started - refresh everything
                checkServerStatus()
                appsModel.load()
                ShizukuSettings.syncAllPlusFeaturesToServer()
                maybeShowVersionSkewSnackbar()
            }
            ShizukuStateMachine.State.STOPPED,
            ShizukuStateMachine.State.CRASHED -> {
                // Shizuku stopped or crashed - refresh status display
                checkServerStatus()
            }
            else -> {
                // Starting or stopping - optional refresh
                checkServerStatus()
            }
        }
    }

    /**
     * When the running privileged server predates the currently-installed app build (the app was
     * updated but the separate server process still runs old code), surface a prompt to restart the
     * service — stale servers can silently break connections for third-party apps until restarted.
     */
    private fun maybeShowVersionSkewSnackbar() {
        if (versionSkewSnackbarShown) return
        if (!ShizukuStateMachine.isServerVersionSkewed()) return
        versionSkewSnackbarShown = true
        SnackbarHelper.show(
            this,
            findViewById(android.R.id.content) ?: window.decorView,
            msg = getString(R.string.snackbar_server_version_skew),
            duration = Snackbar.LENGTH_INDEFINITE,
            actionText = getString(R.string.snackbar_action_restart),
            action = {
                // Stop the stale server; the home UI then shows the normal Start flow, which
                // launches a fresh server on the current build. Mirrors the existing Stop action.
                ShizukuStateMachine.set(ShizukuStateMachine.State.STOPPING)
            }
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        splash.setOnExitAnimationListener { provider ->
            // Some OEM/Android 15 builds return a non-null typed View that is actually null
            // at runtime (platform nullability contract violation).
            // We use safe casting to Any? to prevent R8 from eliding the null check.
            try {
                val iconViewAny: Any? = provider.iconView
                if (iconViewAny is android.view.View) {
                    val animator = iconViewAny.animate()
                    if (animator != null) {
                        animator.alpha(0f)
                            .scaleX(0.8f)
                            .scaleY(0.8f)
                            .setDuration(ShizukuSettings.scaledAnimationDuration(220))
                            .setInterpolator(android.view.animation.PathInterpolator(0.4f, 0f, 1f, 1f))
                            .withEndAction { provider.remove() }
                            .start()
                    } else {
                        provider.remove()
                    }
                } else {
                    provider.remove()
                }
            } catch (_: Exception) {
                runCatching { provider.remove() }
            }
        }
        super.onCreate(savedInstanceState)
        // AppActivity.onCreate() now handles enableEdgeToEdge() for all activities (including
        // the Android 15+ enforcement path). The redundant setDecorFitsSystemWindows() call that
        // was here previously caused inconsistent window state with other activities and contributed
        // to the Explode transition crash on Android 16 (#483).
        if (ShizukuSettings.isBlurUiEnabled() && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            window.setBackgroundBlurRadius(30)
        }

        var showEmptyState by mutableStateOf(false)
        var isEditMode by mutableStateOf(HomeEditMode.isActive)
        val recyclerView = RecyclerView(this).apply {
            id = android.R.id.list
            clipToPadding = false
        }

        setContent {
            val context = LocalContext.current
            af.shizuku.core.ui.compose.AppTheme(
                darkTheme = androidx.compose.foundation.isSystemInDarkTheme(),
                isBlackNightTheme = af.shizuku.manager.app.ThemeHelper.isBlackNightTheme(context),
                isOneUi = isOneUi,
                isRoundedEdges = isRoundedEdges
            ) {
                HomeScreen(
                isEditMode = isEditMode,
                isOneHanded = isOneHanded,
                showEmptyState = showEmptyState,
                isOneUi = isOneUi,
                onStopClick = {
                    if (ShizukuStateMachine.isRunning()) {
                        MaterialAlertDialogBuilder(this)
                            .setMessage(R.string.dialog_stop_message)
                            .setPositiveButton(android.R.string.ok) { _, _ ->
                                ShizukuStateMachine.set(ShizukuStateMachine.State.STOPPING)
                                runCatching { Shizuku.exit() }
                            }
                            .setNegativeButton(android.R.string.cancel, null)
                            .show()
                    }
                },
                onSettingsClick = {
                    startActivity(Intent(this, SettingsActivity::class.java))
                },
                onHelpClick = {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.settings_shizuku_plus_features)
                        .setMessage(getString(R.string.help_general_plus_summary).toHtml())
                        .setPositiveButton(android.R.string.ok, null)
                        .show()
                },
                onDoneClick = { HomeEditMode.exit() },
                onRestoreHomeCards = { adapter.restoreAllCards() },
                recyclerViewProvider = { ctx, paddingValues ->
                    val density = ctx.resources.displayMetrics.density
                    recyclerView.apply {
                        setPadding(
                            paddingLeft,
                            (paddingValues.calculateTopPadding().value * density).toInt(),
                            paddingRight,
                            (paddingValues.calculateBottomPadding().value * density).toInt()
                        )
                    }
                }
            )
            }
        }

        when (intent?.getStringExtra("shortcut_action")) {
            "start_wireless_adb" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                AdbDialogFragment().show(supportFragmentManager)
            }
            "open_terminal" -> startActivity(android.content.Intent(this, af.shizuku.manager.shell.ShellTutorialActivity::class.java))
        }

        // Initial status load
        homeModel.reload()

        homeModel.onEach(HomeState::serviceStatus) {
            if (it is Success) {
                val status = it.invoke()
                val previouslyRunning = wasServiceRunning
                wasServiceRunning = status.isRunning

                // If the service is already running, mark the auto-restart guard so a subsequent
                // manual stop in the same session does not trigger an unwanted re-start.
                if (status.isRunning) autoRestartAttempted = true

                // Auto-reconnect: only when the user has explicitly enabled it in Settings.
                // Gated on isAutoReconnectMdnsEnabled() (default OFF) so a fresh install
                // never silently attempts ADB without user consent.
                if (!status.isRunning && !autoRestartAttempted &&
                    ShizukuSettings.isAutoReconnectMdnsEnabled() &&
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                    ShizukuSettings.getLastLaunchMode() == ShizukuSettings.LaunchMethod.ADB &&
                    checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) == PackageManager.PERMISSION_GRANTED) {
                    val sysPropPort = EnvironmentUtils.getAdbTcpPort()
                    val discoveredPort = withState(homeModel) { s -> s.discoveredAdbPort }
                    val hasLivePort = sysPropPort in 1..65535 || discoveredPort in 1..65535
                    if (hasLivePort) {
                        autoRestartAttempted = true
                        AdbStartWorker.enqueue(this)
                    }
                }

                adapter.updateData()
                ShizukuSettings.setLastLaunchMode(if (status.uid == 0) ShizukuSettings.LaunchMethod.ROOT else ShizukuSettings.LaunchMethod.ADB)

                if (status.isRunning && previouslyRunning == false) {
                    recyclerView.post {
                        val view = recyclerView
                        if (!view.isAttachedToWindow) return@post

                        if (ShizukuSettings.isExpressiveAnimationsEnabled()) {
                            val statusCard = view.findViewHolderForAdapterPosition(0)?.itemView
                            val cx = view.width / 2
                            val cy = statusCard?.let { it.top + it.height / 2 } ?: 100
                            val finalRadius = kotlin.math.hypot(view.width.toDouble(), view.height.toDouble()).toFloat()

                            // OneUI 8+ uses more "elastic" easing (0.22, 1, 0.36, 1)
                            val interpolator = if (EnvironmentUtils.isOneUi8())
                                androidx.core.view.animation.PathInterpolatorCompat.create(0.22f, 1f, 0.36f, 1f)
                            else
                                androidx.core.view.animation.PathInterpolatorCompat.create(0.2f, 0f, 0f, 1f)

                            android.view.ViewAnimationUtils.createCircularReveal(view, cx, cy, 0f, finalRadius).apply {
                                duration = ShizukuSettings.scaledAnimationDuration(if (EnvironmentUtils.isOneUi8()) 800L else 600L)
                                this.interpolator = interpolator
                                start()
                            }
                        }

                        if (EnvironmentUtils.isOneUi8()) {
                            HapticUtils.success(view)
                        }
                    }
                }
            }
        }

        homeModel.onEach(HomeState::shouldShowBatteryOptimizationSnackbar) {
            if (it) {
                SnackbarHelper.show(
                    this,
                    findViewById(android.R.id.content) ?: window.decorView,
                    msg = getString(R.string.snackbar_battery_optimization_home),
                    duration = Snackbar.LENGTH_INDEFINITE,
                    actionText = getString(R.string.snackbar_action_fix),
                    action = {
                        if (EnvironmentUtils.isSamsung()) {
                            SettingsPage.Samsung.DeviceCareBattery.launch(this)
                        } else {
                            SettingsHelper.requestIgnoreBatteryOptimizations(this, null)
                        }
                    }
                )
            }
        }
        homeModel.checkBatteryOptimization()

        // Samsung Auto Blocker hint — show at most once per session to avoid repeating on
        // every status refresh while the service stays stopped.
        if (EnvironmentUtils.isSamsung() && EnvironmentUtils.getOneUiVersion() >= 6) {
            homeModel.onEach(HomeState::serviceStatus) {
                if (!autoBlockerSnackbarShown && it is Success && it.invoke().isRunning == false) {
                    autoBlockerSnackbarShown = true
                    SnackbarHelper.show(
                        this,
                        findViewById(android.R.id.content) ?: window.decorView,
                        msg = getString(R.string.snackbar_samsung_auto_blocker),
                        duration = Snackbar.LENGTH_LONG,
                        actionText = getString(R.string.snackbar_action_check),
                        action = {
                            SettingsPage.Samsung.AutoBlocker.launch(this)
                        }
                    )
                }
            }
        }

        appsModel.grantedCount.observe(this) {
            if (it.status == Status.SUCCESS) {
                homeModel.updateGrantedAppCount(it.data ?: 0)
                adapter.updateData()
            }
        }

        requestNotificationPermissionIfNeeded()

        // Check for updates on app startup (if enabled)
        checkForUpdates()

        // Responsive grid for large screens and DeX (#76) - single column on phones preserves
        // the original Shizuku look, 2 columns kicks in on tablets/landscape/DeX where a single
        // column of cards leaves most of the width empty.
        val spanCount = if (resources.configuration.screenWidthDp >= 600 ||
            resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        ) 2 else 1
        val layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, spanCount)
        layoutManager.spanSizeLookup = object : androidx.recyclerview.widget.GridLayoutManager.SpanSizeLookup() {
            // The status card (position 0) always takes the full width for visibility.
            override fun getSpanSize(position: Int): Int = if (position == 0) spanCount else 1
        }
        recyclerView.layoutManager = layoutManager

        // Samsung DeX Specific: add 'sidebar' feel with larger horizontal margins
        val isDeX = EnvironmentUtils.isSamsung() && EnvironmentUtils.isDeX(this)
        val dexPadding = if (isDeX) (48 * resources.displayMetrics.density).toInt() else 0

        recyclerView.adapter = adapter
        (recyclerView.itemAnimator as? androidx.recyclerview.widget.SimpleItemAnimator)?.supportsChangeAnimations = false
        recyclerView.fixEdgeEffect()

        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(recyclerView) { v, insets ->
            val systemBars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout())
            v.setPadding(
                systemBars.left + dexPadding,
                v.paddingTop,
                systemBars.right + dexPadding,
                v.paddingBottom
            )
            insets
        }

        // Listen for empty state changes
        adapter.onEmptyStateChanged = { isEmpty ->
            showEmptyState = isEmpty
        }

        val cardSpacing = resources.getDimension(R.dimen.card_spacing)
        val marginHorizontal = resources.getDimension(R.dimen.margin_horizontal)
        val marginVertical = resources.getDimension(R.dimen.margin_vertical)

        val itemSpacing = cardSpacing / 2f
        val edgeSpacingH = marginHorizontal
        val edgeSpacingV = marginVertical - itemSpacing

        recyclerView.addItemSpacing(top = itemSpacing, bottom = itemSpacing)
        recyclerView.addEdgeSpacing(top = edgeSpacingV, bottom = edgeSpacingV, left = edgeSpacingH, right = edgeSpacingH)

        // Drag-to-reorder support
        val dragCallback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun isLongPressDragEnabled() = false

            override fun getMovementFlags(rv: RecyclerView, vh: RecyclerView.ViewHolder): Int {
                return if (adapter.isDraggable(vh.bindingAdapterPosition))
                    makeMovementFlags(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0)
                    else
                    makeMovementFlags(0, 0)
                    }

                    override fun onMove(rv: RecyclerView, src: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                if (!adapter.isDraggable(target.bindingAdapterPosition)) return false
                adapter.moveItem(src.bindingAdapterPosition, target.bindingAdapterPosition)
                HapticUtils.tap(target.itemView)
                return true
            }

            override fun onSelectedChanged(viewHolder: RecyclerView.ViewHolder?, actionState: Int) {
                super.onSelectedChanged(viewHolder, actionState)
                if (actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                    adapter.isDragging = true
                    viewHolder?.itemView?.let { HapticUtils.gestureStart(it) }
                    if (ShizukuSettings.isExpressiveAnimationsEnabled()) {
                        viewHolder?.itemView?.animate()
                            ?.scaleX(1.04f)
                            ?.scaleY(1.04f)
                            ?.translationZ(16f)
                            ?.setDuration(ShizukuSettings.scaledAnimationDuration(200))
                            ?.setInterpolator(android.view.animation.DecelerateInterpolator())
                            ?.start()
                    }
                } else if (actionState == ItemTouchHelper.ACTION_STATE_IDLE) {
                    adapter.isDragging = false
                }
            }

            override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {}

            override fun clearView(rv: RecyclerView, vh: RecyclerView.ViewHolder) {
                super.clearView(rv, vh)
                adapter.isDragging = false
                if (ShizukuSettings.isExpressiveAnimationsEnabled()) {
                    val animator = vh.itemView.animate()
                    if (animator != null) {
                        animator.scaleX(1f)
                            .scaleY(1f)
                            .translationZ(0f)
                            .setDuration(ShizukuSettings.scaledAnimationDuration(250))
                            .setInterpolator(android.view.animation.OvershootInterpolator(0.8f))
                            .start()
                    } else {
                        vh.itemView.scaleX = 1f
                        vh.itemView.scaleY = 1f
                        vh.itemView.translationZ = 0f
                    }
                }
                adapter.persistCardOrder()
                adapter.updateData()
            }
        }
        val itemTouchHelper = ItemTouchHelper(dragCallback)
        itemTouchHelper.attachToRecyclerView(recyclerView)

        HomeEditMode.startDragCallback = { vh -> itemTouchHelper.startDrag(vh) }
        HomeEditMode.exit()

        // Predictive back support for edit mode with expressive M3 scaling
        val backCallback = object : androidx.activity.OnBackPressedCallback(HomeEditMode.isActive) {
            private var backThresholdReached = false

            override fun handleOnBackProgressed(backEvent: androidx.activity.BackEventCompat) {
                val progress = backEvent.progress

                if (progress > 0.1f && !backThresholdReached) {
                    backThresholdReached = true
                    HapticUtils.gestureThreshold(recyclerView)
                } else if (progress < 0.1f) {
                    backThresholdReached = false
                }

                if (ShizukuSettings.isExpressiveAnimationsEnabled()) {
                    // Subtle parabolic scale and alpha for more "physical" feel
                    val scale = 1f - (0.08f * progress * progress)
                    recyclerView.scaleX = scale
                    recyclerView.scaleY = scale
                    recyclerView.alpha = 1f - (0.15f * progress)
                }
            }

            override fun handleOnBackPressed() {
                backThresholdReached = false
                if (HomeEditMode.isActive) {
                    HomeEditMode.exit()
                    if (ShizukuSettings.isExpressiveAnimationsEnabled()) {
                        val animator = recyclerView.animate()
                        if (animator != null) {
                            animator.scaleX(1f)
                                .scaleY(1f)
                                .alpha(1f)
                                .setDuration(ShizukuSettings.scaledAnimationDuration(400))
                                .setInterpolator(androidx.core.view.animation.PathInterpolatorCompat.create(0.2f, 0f, 0f, 1f))
                                .start()
                        } else {
                            recyclerView.scaleX = 1f
                            recyclerView.scaleY = 1f
                            recyclerView.alpha = 1f
                        }
                    }
                }
            }

            override fun handleOnBackCancelled() {
                if (ShizukuSettings.isExpressiveAnimationsEnabled()) {
                    val animator = recyclerView.animate()
                    if (animator != null) {
                        animator.scaleX(1f)
                            .scaleY(1f)
                            .alpha(1f)
                            .setDuration(ShizukuSettings.scaledAnimationDuration(300))
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                    } else {
                        recyclerView.scaleX = 1f
                        recyclerView.scaleY = 1f
                        recyclerView.alpha = 1f
                    }
                }
            }
        }
        onBackPressedDispatcher.addCallback(this, backCallback)

        HomeEditMode.onChanged = {
            lifecycleScope.launch {
                delay(150)
                isEditMode = HomeEditMode.isActive
                homeModel.setEditMode(HomeEditMode.isActive)
                adapter.updateData()
                backCallback.isEnabled = HomeEditMode.isActive
            }
        }

        ShizukuStateMachine.addListener(stateListener)
        ShizukuSettings.getPreferences()?.registerOnSharedPreferenceChangeListener(appearanceChangeListener)

        // Handle cold-start launch from the ADB pairing success notification.
        // onNewIntent() is only called when the activity already exists; when the app
        // is not running the system calls onCreate() with the launch intent instead.
        if (intent?.getBooleanExtra(HomeActivity.EXTRA_START_SERVICE_VIA_WADB, false) == true) {
            handleStartViaMdnsNotification()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val showDialog = intent.getBooleanExtra(HomeActivity.EXTRA_SHOW_PAIRING_DIALOG, false)
        if (showDialog) showAccessibilityDialog()

        if (intent.getBooleanExtra(HomeActivity.EXTRA_START_SERVICE_VIA_WADB, false)) {
            handleStartViaMdnsNotification()
        }
    }

    private fun handleStartViaMdnsNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(AdbPairingService.NOTIFICATION_ID)
        val discoveredPort = withState(homeModel) { s -> s.discoveredAdbPort }
        StartWirelessAdbViewHolder.start(this, lifecycleScope, discoveredPort)
    }

    override fun onResume() {
        super.onResume()
        // Sync one-handed mode and OneUI theme compose state in case it changed while in settings.
        isOneHanded = ShizukuSettings.isOneHandedModeEnabled()
        isOneUi = ShizukuSettings.isOneUiThemeEnabled()
        isRoundedEdges = ShizukuSettings.isRoundedEdgesEnabled()
        // Synchronously rebind all visible cards so appearance-setting changes (icon style, shape
        // style, etc.) are visible immediately when returning from SettingsActivity. The async
        // checkServerStatus() / homeModel.reload() path updates service-status content but involves
        // a Loading → Success state cycle that completes AFTER the first frame is painted, so
        // without this call the user would see the stale style for one navigation round-trip.
        adapter.notifyDataSetChanged()
        checkServerStatus()
        appsModel.load()
    }

    override fun onPause() {
        super.onPause()
        SnackbarHelper.dismiss()
    }

    override fun invalidate() {
        // Mavericks state changed - individual property observers (onEach) handle specific updates
    }

    private fun checkServerStatus() {
        homeModel.reload()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (ShizukuSettings.hasRequestedHomeNotificationPermission()) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        ShizukuSettings.setRequestedHomeNotificationPermission(true)
        notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onDestroy() {
        HomeEditMode.onChanged = null
        HomeEditMode.startDragCallback = null
        HomeEditMode.removeCardCallback = null
        ShizukuStateMachine.removeListener(stateListener)
        ShizukuSettings.getPreferences()?.unregisterOnSharedPreferenceChangeListener(appearanceChangeListener)
        activeUpdateManager?.cancel()
        activeUpdateManager = null
        super.onDestroy()
    }


    /**
     * Check for updates on app startup and show popup dialog
     */
    private fun checkForUpdates() {
        if (!ShizukuSettings.isAutoUpdateEnabled()) {
            return
        }

        // Check if we've already checked today
        val lastCheckTime = ShizukuSettings.getLastUpdateCheckTime()
        val now = System.currentTimeMillis()
        val oneDayInMillis = 24 * 60 * 60 * 1000L

        if (now - lastCheckTime < oneDayInMillis) {
            return
        }

        if (isFinishing || isDestroyed) return

        // Check for updates silently in background
        lifecycleScope.launch {
            try {
                val result = UpdateChecker.checkForUpdate(ShizukuSettings.getUpdateChannel())

                when (result) {
                    is UpdateChecker.CheckResult.UpdateAvailable -> {
                        ShizukuSettings.setLastUpdateCheckTime(now)
                        ShizukuSettings.setLastUpdateCheckFailed(false)
                        if (!isFinishing && !isDestroyed) showUpdateAvailableDialog(result.info)
                    }
                    is UpdateChecker.CheckResult.UpToDate -> {
                        ShizukuSettings.setLastUpdateCheckTime(now)
                        ShizukuSettings.setLastUpdateCheckFailed(false)
                    }
                    is UpdateChecker.CheckResult.NetworkError -> {
                        ShizukuSettings.setLastUpdateCheckFailed(true)
                    }
                }
            } catch (e: Exception) {
                Timber.tag("HomeActivity").e(e, "Unexpected error checking for update")
                ShizukuSettings.setLastUpdateCheckFailed(true)
            }
        }
    }

    /**
     * Show update available popup dialog
     */
    private fun showUpdateAvailableDialog(updateInfo: UpdateChecker.UpdateInfo) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_update_available, null)
        dialogView.findViewById<TextView>(R.id.update_version_name).text = "Version ${updateInfo.versionName}"
        dialogView.findViewById<TextView>(R.id.update_published_date).text =
            if (updateInfo.publishedAt.isNotEmpty())
                "Published: ${UpdateChecker.formatPublishedDate(updateInfo.publishedAt)}"
            else ""
        // updateInfo.releaseNotes is the raw GitHub release body (Markdown) - render it instead
        // of dumping it as plain text, which showed literal "**", "###", "|...|" table syntax
        // and bracketed links to users. Drop the "Recent Releases" rollup (table/links meant for
        // the GitHub page, not a compact popup) the same way ChangelogDialogFragment does.
        val notesBody = updateInfo.releaseNotes
            .substringBefore("## 📦 Recent Releases")
            .trim()
            .ifEmpty { getString(R.string.update_no_release_notes) }
        val releaseNotesView = dialogView.findViewById<TextView>(R.id.update_release_notes)
        Markwon.create(this).setMarkdown(releaseNotesView, notesBody)
        releaseNotesView?.movementMethod = LinkMovementMethod.getInstance()

        val openReleases = {
            startActivity(
                android.content.Intent(android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://github.com/thejaustin/ShizukuPlus/releases"))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.update_available_title)
            .setView(dialogView)
            .setNegativeButton(R.string.update_later, null)
            .setNeutralButton(R.string.update_release_notes) { _, _ -> openReleases() }

        if (updateInfo.requiresManualDownload) {
            builder.setPositiveButton(R.string.update_view_on_github) { _, _ -> openReleases() }
        } else {
            builder.setPositiveButton(R.string.update_download) { _, _ ->
                activeUpdateManager?.cancel()
                activeUpdateManager = UpdateManager(this).also {
                    it.downloadUpdate(updateInfo.downloadUrl, updateInfo.versionName)
                }
            }
        }

        builder.show()
    }

    companion object {
        const val EXTRA_SHOW_PAIRING_DIALOG = "show_pairing_dialog"
        const val EXTRA_START_SERVICE_VIA_WADB = "start_service_via_wadb"
    }

}
