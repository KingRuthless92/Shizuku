package af.shizuku.manager.home

import com.airbnb.mvrx.Loading
import com.airbnb.mvrx.test.MavericksTestRule
import com.airbnb.mvrx.withState
import io.kotest.matchers.shouldBe
import io.kotest.matchers.types.shouldBeInstanceOf
import org.junit.Rule
import org.junit.Test

class HomeViewModelTest {

    @get:Rule
    val mavericksTestRule = MavericksTestRule()

    @Test
    fun `initial state is Loading and then Success or Fail`() {
        val viewModel = HomeViewModel(HomeState()) // Fixed arguments
        
        withState(viewModel) { state ->
            // In a real test we'd mock Shizuku.pingBinder() etc.
            // For now just verify it's not Uninitialized
            state.serviceStatus.shouldBeInstanceOf<Loading<*>>()
        }
    }

    @Test
    fun `setEditMode updates state`() {
        val viewModel = HomeViewModel(HomeState())
        
        viewModel.setEditMode(true)
        
        withState(viewModel) { state ->
            state.isEditMode shouldBe true
        }
    }
}
