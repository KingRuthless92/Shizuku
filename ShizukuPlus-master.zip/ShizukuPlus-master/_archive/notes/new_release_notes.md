## Shizuku+ Major Update & Compatibility Fixes

This release rolls up all changes from recent build iterations that suffered from launch crashes (due to ProGuard obfuscation) and compatibility issues (due to package renaming and provider authority conflicts). It represents a stable milestone with **full backwards compatibility** for original Shizuku applications.

### 🐛 Edit / Crash Release Notes from Previous Builds
The previous releases (`r1637` through `r1690`) had the following critical issues that are now resolved:
- **Mavericks ViewModel Crash:** Release builds crashed instantly on launch (`java.lang.IllegalArgumentException`) because ProGuard/R8 was stripping the `HomeViewModel` companion factory. Fixed by adding aggressive `@Keep` annotations to prevent mangling of reflection metadata.
- ~~**Permission Declaration Conflict:** Previous builds declared the original `moe.shizuku.manager.permission.API_V23` in the manifest. This caused Android to block installation if the original Shizuku was present (or vice-versa) due to a package name overlap in the permission group. This has been removed; Shizuku+ now uses its own permission group exclusively.~~
- ~~**Provider Authority Conflict:** Previous attempts to support original Shizuku apps by declaring `moe.shizuku.privileged.api.shizuku` in the manifest led to `INSTALL_FAILED_CONFLICTING_PROVIDER` when installed alongside the original app. This conflicting authority has been removed.~~
- **Sentry Vendor Diagnostic Crash:** Early initialization crashes occurred on devices with strict hidden API restrictions (TCL/Oppo/Samsung) because Sentry was probing `SystemProperties` before the `HiddenApiBypass` was activated. The initialization sequence has been reordered to prevent this.

### ✨ Highlights Added in this Build
- **Original Shizuku App Compatibility:** Shizuku+ now explicitly delivers service binders directly to the internal ContentProviders of client apps using both the new and the legacy (`rikka.shizuku.intent.extra.BINDER`) intent keys. Apps compiled against the original `moe.shizuku.privileged.api` will work seamlessly.
- **Seamless Auto-Update & Migration:** Added a robust `UpdateInstaller` that detects signature mismatches or package differentiation errors during an update. If a conflict is found, it:
  1. Auto-exports your settings.
  2. Uses a detached Shizuku/Root shell script to uninstall the old app and install the new APK.
  3. Auto-grants critical permissions (`POST_NOTIFICATIONS`, `WRITE_SECURE_SETTINGS`, `SYSTEM_ALERT_WINDOW`, `GET_USAGE_STATS`) post-install.
  4. Auto-imports your settings upon the next launch.

### 📋 Full Changelog since last stable release (v13.6.0.r1636-shizukuplus)
- feat: advanced AICore+ method stubs and physical input simulation (touch, swipe, text)
- feat: Binder Firewall (Issue #199) - block sensitive system transactions (e.g. reboot)
- feat: AIDL Transaction Logging (Issue #199) - audit proxied Binder calls in Logcat
- feat: Shadow Binder hook (Issue #199) - architecture for system service mocking
- feat: settings UI toggles and server-sync for new Binder enhancements
- fix(coexistence): remove conflicting original Shizuku permission and update autoResConfig (9ce8f1a2)
- enhancement(update): auto-grant critical permissions post-install for seamless auto-update (9503daf2)
- feat(update): implement auto-backup and force update via Shizuku/Root on signature mismatch (458a483f)
- fix(proguard): aggressively keep HomeViewModel and Companion using @Keep annotation for Mavericks (83530293)
- fix: resolve Mavericks ViewModel crash and ensure compatibility with original Shizuku client apps (87bec2d8)
- build: disable abortOnError in lint to prevent CI failures from strict checks (428c68b2)
- fix: downgrade leakcanary to 2.14 (v2.15 does not exist) (b7f22a11)
- fix: resolve unresolved references and missing imports (6def31da)
- fix: resolve XML namespace error in settings_root_integration.xml (30791a7d)
- fix: resolve BuildConfig.VERSION_CODE compilation error in MainActivity (7ce02c34)
- docs: update README and add Shizuku vs Shizuku+ wiki comparison (4bcec41d)
- feat: Dhizuku Mode DO support, AICore+ bridge, and in-app changelogs (dc9fd15e)
- docs(devlog): record KSP2/Room constraint and session notes (395b2d6e)
- fix(ksp): disable KSP2 to restore Room 2.6.1 compatibility (304480f5)
- fix(database): remove extra closing brace in build.gradle (d89e9255)
- fix(ci): accept SDK licenses in lint job; remove duplicate string key (2cb61cd4)
- fix: graceful libadb.so degradation + Mavericks/SQLite crash fixes (e80662cd)
- Polish M3E shortcuts/splash, extract strings, dedupe theme color lookups (9117abee)
- refactor(home): dedup scene transition + fix entrance animation/Lottie probe (bbfebeac)
- ci: drop runtime gradle.properties append (ed704fe2)
- deps: bump sentry, coil, lifecycle (84306839)
- chore(dev): bake gradle cache + add AI-agent docs and dev scripts (796479bd)
- docs(widget): note RemoteViews constraint forbids MaterialButton (63880411)
- feat(ui): finish M3 Expressive coverage — MaterialButton everywhere, lib bump (d9261f32)
- fix: use updatePaddingRelative for end-padding in HomeEditMode overlay (b25372b0)
- fix(ui): clear card-content overlap and force M3 MaterialSwitch on prefs (fbb74919)
- fix(ci): generate release notes from git log between tags (89eb8bbc)
- fix: resolve color attrs from app R, not Material R (22729d43)
- feat: wire up icon_style preference toggle (7911c676)
- fix: render toolbar action icons by switching to app:showAsAction (4c925863)
- fix: replace mavericksViewModel() with viewModel() for Activity scope (fae30d63)
- fix: resolve all pre-existing compile errors across 7 files (df8fd3a1)
- docs: update AI_DEVLOG with Apr 24 session and new crash rules (3b7f19cb)
- fix: repair StartWirelessAdbViewHolder compilation errors (91fd5c25)
- fix: close unclosed LinearLayout tags in two tutorial layouts (c1150113)
- fix: remove unused import, add Shizuku-aware info banner, update release notes (ec52ff71)
- chore: restore April 2026 Sentry guard and update AI_DEVLOG (2227c957)
- chore: remove expired April 2026 Sentry flag and upgrade LogAdapter to DiffUtil (694eea28)
- docs: add AI_DEVLOG.md — cross-session planning and backlog tracker (997b54be)
- fix: crash fixes, M3 transitions, and layout architecture repairs (98f47424)
- feat: implement robust manual crash reporting system (827754ec)
- a11y: fix decorative icon accessibility and add drag/remove descriptions (153cfe05)
- fix: add overlay_manager_plus and network_governor_plus enhancement mappings (e9002881)
- feat: settings import/export in Developer Options (b0176fd2)
- fix: DhizukuProvider permission check was dead code (empty if body) (003fd16f)
- fix: SU Bridge bounds guards and su wrapper RISH_APPLICATION_ID (19c1a1d0)
- fix: su wrapper must export RISH_APPLICATION_ID before calling rish (cae96617)
- a11y: mark decorative expand arrow as importantForAccessibility=no (1fa4c7a6)
- perf: move checkAppIntegrations package checks to IO dispatcher (c5f2307e)
- chore: remove stale TODO comment from onPermissionRevoked (4dae3a0a)
- fix: use sealed ListItem in Root Compat adapter; sync activity log to server (fbcc1cd7)
- feat: auto-close terminal and pairing screens when Shizuku is ready (a1dcaf96)
- fix: shell injection, watchdog backoff, SettingsPage cleanup + CHANGES.md (0d47caba)
- docs: restore 'whose work makes Shizuku+ possible' in acknowledgements (3adccb27)
- docs: soften tone and fix possessive language in attributions (663f6495)
- docs: restore Muntashir Akon credit, fix aShell GPL boundary (fbbec7e6)