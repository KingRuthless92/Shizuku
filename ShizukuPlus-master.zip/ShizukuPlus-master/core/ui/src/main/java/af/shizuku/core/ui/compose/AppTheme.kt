package af.shizuku.core.ui.compose

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.material.color.MaterialColors
import com.google.android.material.R as MaterialR

/**
 * Reads the ColorScheme from the hosting Activity's own theme instead of having Compose decide
 * dynamic-color/custom-accent/default independently. By the time this runs, AppActivity's
 * onApplyUserThemeResource (see ThemeDelegateImpl) has already applied the correct ThemeOverlay -
 * system dynamic color, a custom accent, the default blue, or black night theme - to the hosting
 * Activity's theme. Reading those resolved attributes keeps Compose screens visually identical to
 * the rest of the (XML-themed) app instead of falling back to Compose's own generic baseline
 * scheme whenever dynamic color isn't available or a custom accent is set.
 */
private fun androidColorScheme(context: Context, darkTheme: Boolean): ColorScheme {
    val fallback = if (darkTheme) darkColorScheme() else lightColorScheme()
    fun color(attr: Int, fallbackColor: Color) =
        Color(MaterialColors.getColor(context, attr, fallbackColor.toArgb()))

    // colorPrimary and colorError are declared by appcompat, not material - with non-transitive
    // R classes they only exist in appcompat's R.
    val primary = color(androidx.appcompat.R.attr.colorPrimary, fallback.primary)
    val onPrimary = color(MaterialR.attr.colorOnPrimary, fallback.onPrimary)
    val primaryContainer = color(MaterialR.attr.colorPrimaryContainer, fallback.primaryContainer)
    val onPrimaryContainer = color(MaterialR.attr.colorOnPrimaryContainer, fallback.onPrimaryContainer)
    val secondary = color(MaterialR.attr.colorSecondary, fallback.secondary)
    val onSecondary = color(MaterialR.attr.colorOnSecondary, fallback.onSecondary)
    val secondaryContainer = color(MaterialR.attr.colorSecondaryContainer, fallback.secondaryContainer)
    val onSecondaryContainer = color(MaterialR.attr.colorOnSecondaryContainer, fallback.onSecondaryContainer)
    val tertiary = color(MaterialR.attr.colorTertiary, fallback.tertiary)
    val onTertiary = color(MaterialR.attr.colorOnTertiary, fallback.onTertiary)
    val tertiaryContainer = color(MaterialR.attr.colorTertiaryContainer, fallback.tertiaryContainer)
    val onTertiaryContainer = color(MaterialR.attr.colorOnTertiaryContainer, fallback.onTertiaryContainer)
    val error = color(androidx.appcompat.R.attr.colorError, fallback.error)
    val onError = color(MaterialR.attr.colorOnError, fallback.onError)
    val errorContainer = color(MaterialR.attr.colorErrorContainer, fallback.errorContainer)
    val onErrorContainer = color(MaterialR.attr.colorOnErrorContainer, fallback.onErrorContainer)
    val background = color(android.R.attr.colorBackground, fallback.background)
    val onBackground = color(MaterialR.attr.colorOnBackground, fallback.onBackground)
    val surface = color(MaterialR.attr.colorSurface, fallback.surface)
    val onSurface = color(MaterialR.attr.colorOnSurface, fallback.onSurface)
    val surfaceVariant = color(MaterialR.attr.colorSurfaceVariant, fallback.surfaceVariant)
    val onSurfaceVariant = color(MaterialR.attr.colorOnSurfaceVariant, fallback.onSurfaceVariant)
    val outline = color(MaterialR.attr.colorOutline, fallback.outline)
    val outlineVariant = color(MaterialR.attr.colorOutlineVariant, fallback.outlineVariant)
    val scrim = color(MaterialR.attr.scrimBackground, fallback.scrim)
    val surfaceBright = color(MaterialR.attr.colorSurfaceBright, fallback.surfaceBright)
    val surfaceDim = color(MaterialR.attr.colorSurfaceDim, fallback.surfaceDim)
    val surfaceContainer = color(MaterialR.attr.colorSurfaceContainer, fallback.surfaceContainer)
    val surfaceContainerHigh = color(MaterialR.attr.colorSurfaceContainerHigh, fallback.surfaceContainerHigh)
    val surfaceContainerHighest = color(MaterialR.attr.colorSurfaceContainerHighest, fallback.surfaceContainerHighest)
    val surfaceContainerLow = color(MaterialR.attr.colorSurfaceContainerLow, fallback.surfaceContainerLow)
    val surfaceContainerLowest = color(MaterialR.attr.colorSurfaceContainerLowest, fallback.surfaceContainerLowest)

    // darkColorScheme()/lightColorScheme() are plain functions (not a shared type with a common
    // named-argument call), so a stored function reference can't be invoked with named args here -
    // hence the duplicated call rather than picking one reference to invoke once.
    return if (darkTheme) {
        darkColorScheme(
            primary = primary, onPrimary = onPrimary,
            primaryContainer = primaryContainer, onPrimaryContainer = onPrimaryContainer,
            secondary = secondary, onSecondary = onSecondary,
            secondaryContainer = secondaryContainer, onSecondaryContainer = onSecondaryContainer,
            tertiary = tertiary, onTertiary = onTertiary,
            tertiaryContainer = tertiaryContainer, onTertiaryContainer = onTertiaryContainer,
            error = error, onError = onError,
            errorContainer = errorContainer, onErrorContainer = onErrorContainer,
            background = background, onBackground = onBackground,
            surface = surface, onSurface = onSurface,
            surfaceVariant = surfaceVariant, onSurfaceVariant = onSurfaceVariant,
            outline = outline,
            outlineVariant = outlineVariant,
            scrim = scrim,
            surfaceBright = surfaceBright,
            surfaceDim = surfaceDim,
            surfaceContainer = surfaceContainer,
            surfaceContainerHigh = surfaceContainerHigh,
            surfaceContainerHighest = surfaceContainerHighest,
            surfaceContainerLow = surfaceContainerLow,
            surfaceContainerLowest = surfaceContainerLowest,
        )
    } else {
        lightColorScheme(
            primary = primary, onPrimary = onPrimary,
            primaryContainer = primaryContainer, onPrimaryContainer = onPrimaryContainer,
            secondary = secondary, onSecondary = onSecondary,
            secondaryContainer = secondaryContainer, onSecondaryContainer = onSecondaryContainer,
            tertiary = tertiary, onTertiary = onTertiary,
            tertiaryContainer = tertiaryContainer, onTertiaryContainer = onTertiaryContainer,
            error = error, onError = onError,
            errorContainer = errorContainer, onErrorContainer = onErrorContainer,
            background = background, onBackground = onBackground,
            surface = surface, onSurface = onSurface,
            surfaceVariant = surfaceVariant, onSurfaceVariant = onSurfaceVariant,
            outline = outline,
            outlineVariant = outlineVariant,
            scrim = scrim,
            surfaceBright = surfaceBright,
            surfaceDim = surfaceDim,
            surfaceContainer = surfaceContainer,
            surfaceContainerHigh = surfaceContainerHigh,
            surfaceContainerHighest = surfaceContainerHighest,
            surfaceContainerLow = surfaceContainerLow,
            surfaceContainerLowest = surfaceContainerLowest,
        )
    }
}

// Mirrors ShapeAppearance.OneUI.Corner.{ExtraSmall,Small,Medium,Large,ExtraLarge}
// (manager/src/main/res/values/themes_overlay.xml) so Compose screens match One UI's rounder
// corner language exactly like the XML side does when ThemeOverlay.OneUI is applied. Only used
// when the caller passes isOneUi = true (see ShizukuSettings.isOneUiThemeEnabled()) - Compose's
// stock Material3 Shapes() is left untouched for every other Shape Style (Modern/Classic/Squircle).
private val OneUiShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(36.dp),
)

private val OneUiTypography = Typography(
    headlineLarge = Typography().headlineLarge.copy(
        fontWeight = FontWeight.ExtraBold,
        fontSize = 32.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = Typography().headlineMedium.copy(
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        letterSpacing = (-0.25).sp
    ),
    headlineSmall = Typography().headlineSmall.copy(
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    titleLarge = Typography().titleLarge.copy(
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        letterSpacing = (-0.15).sp
    ),
    titleMedium = Typography().titleMedium.copy(
        fontWeight = FontWeight.Bold,
        fontSize = 16.sp
    ),
    titleSmall = Typography().titleSmall.copy(
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp
    ),
    labelLarge = Typography().labelLarge.copy(
        fontWeight = FontWeight.SemiBold
    ),
    labelMedium = Typography().labelMedium.copy(
        fontWeight = FontWeight.SemiBold
    ),
    labelSmall = Typography().labelSmall.copy(
        fontWeight = FontWeight.Medium
    ),
    bodyLarge = Typography().bodyLarge.copy(
        fontSize = 16.sp,
        letterSpacing = 0.sp
    ),
    bodyMedium = Typography().bodyMedium.copy(
        fontSize = 14.sp,
        letterSpacing = 0.sp
    ),
    bodySmall = Typography().bodySmall.copy(
        fontSize = 12.sp,
        letterSpacing = 0.sp
    )
)

private val SharpShapes = Shapes(
    extraSmall = RoundedCornerShape(0.dp),
    small = RoundedCornerShape(0.dp),
    medium = RoundedCornerShape(0.dp),
    large = RoundedCornerShape(0.dp),
    extraLarge = RoundedCornerShape(0.dp),
)

@Composable
fun AppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    isBlackNightTheme: Boolean = false,
    isOneUi: Boolean = false,
    isRoundedEdges: Boolean = true,
    themeVersion: Int = 0,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    var colorScheme = remember(context, darkTheme, themeVersion) { androidColorScheme(context, darkTheme) }

    // Belt-and-suspenders: ThemeOverlay.Black (applied via onApplyUserThemeResource) already
    // forces colorSurface/android:colorBackground to black, so this should be redundant with the
    // read above - kept in case a future overlay change misses one of the two attributes.
    if (darkTheme && isBlackNightTheme) {
        colorScheme = colorScheme.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceDim = Color.Black,
            surfaceContainerLowest = Color.Black,
            surfaceContainerLow = Color.Black,
            // Extend to the full surface-container tone scale so components that draw
            // from surfaceContainer* (SearchBar suggestion pane, settings-search card,
            // bottom sheets, etc.) also render black in AMOLED mode (#496).
            surfaceContainer = Color(0xFF0A0A0A),
            surfaceContainerHigh = Color(0xFF0D0D0D),
            surfaceContainerHighest = Color(0xFF111111),
        )
    }

    val shapes = when {
        !isRoundedEdges -> SharpShapes
        isOneUi -> OneUiShapes
        else -> Shapes()
    }
    val typography = if (isOneUi) OneUiTypography else Typography()

    MaterialTheme(
        colorScheme = colorScheme,
        shapes = shapes,
        typography = typography,
        content = content
    )
}
