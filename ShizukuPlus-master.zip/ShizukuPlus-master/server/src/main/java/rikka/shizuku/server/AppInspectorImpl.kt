package rikka.shizuku.server

import android.content.pm.PackageManager
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.ServiceManager
import android.util.Log
import af.shizuku.server.IAppInspector
import af.shizuku.common.compat.Android17Compat
import af.shizuku.common.util.UserHandleCompat
import rikka.hidden.compat.ActivityManagerApis
import rikka.shizuku.server.api.IContentProviderUtils
import java.io.File
import java.nio.file.Files

class AppInspectorImpl : IAppInspector.Stub() {

    companion object {
        private const val TAG = "AppInspector"

        private fun activityManagerService(): Any? = try {
            val binder = ServiceManager.getService("activity") ?: return null
            Class.forName("android.app.IActivityManager\$Stub")
                .getDeclaredMethod("asInterface", IBinder::class.java)
                .invoke(null, binder)
        } catch (_: Exception) { null }

        private fun callingUserId() = UserHandleCompat.getUserId(Binder.getCallingUid())
    }

    private fun execOutput(vararg args: String): String = try {
        val proc = Runtime.getRuntime().exec(args)
        try {
            val out = proc.inputStream.bufferedReader().use { it.readText() }
            proc.waitFor()
            out.trim()
        } finally {
            proc.destroy()
        }
    } catch (_: Exception) { "" }

    private fun pipeProcess(vararg args: String): ParcelFileDescriptor? = try {
        val (readSide, writeSide) = ParcelFileDescriptor.createPipe()
        Thread {
            try {
                val proc = Runtime.getRuntime().exec(args)
                try {
                    proc.inputStream.use { src ->
                        ParcelFileDescriptor.AutoCloseOutputStream(writeSide).use { dst ->
                            src.copyTo(dst)
                        }
                    }
                    proc.waitFor()
                } finally {
                    proc.destroy()
                }
            } catch (_: Exception) {
                try { writeSide.close() } catch (_: Exception) {}
            }
        }.also { it.isDaemon = true }.start()
        readSide
    } catch (_: Exception) { null }

    override fun backupViaSystemAgent(packageName: String?): ParcelFileDescriptor? {
        if (packageName.isNullOrBlank()) return null
        // 'bu' is /system/bin/bu — the backup unit command used internally by 'adb backup'.
        // On Android ≤ 11, shell uid can call it without BACKUP permission because it was
        // designed for ADB (which already holds elevated trust). Android 12+ tightened this.
        // Output is a raw ADB backup stream: "ANDROID BACKUP" header + gzip-compressed tar.
        return pipeProcess("bu", "backup", "-noapk", packageName)
    }

    override fun dumpHeap(pid: Int, destPath: String?): Boolean {
        if (pid <= 0 || destPath.isNullOrBlank()) return false
        // Primary: IActivityManager.dumpHeap — passes a PFD instead of spawning am dumpheap
        try {
            val am = activityManagerService() ?: error("no activity service")
            val destFile = File(destPath)
            destFile.parentFile?.mkdirs()
            val pfd = ParcelFileDescriptor.open(
                destFile,
                ParcelFileDescriptor.MODE_WRITE_ONLY or
                ParcelFileDescriptor.MODE_CREATE or
                ParcelFileDescriptor.MODE_TRUNCATE
            )
            pfd.use {
                val invoked = am.javaClass.methods.filter { it.name == "dumpHeap" }.any { m ->
                    runCatching {
                        // Param-count dispatch across API 26-35 variants:
                        // (String, int, boolean, String, PFD, RemoteCallback) — API 26-28
                        // (String, int, boolean, boolean, boolean, String, PFD, RemoteCallback) — API 29+
                        when (m.parameterTypes.size) {
                            6 -> { m.invoke(am, pid.toString(), -1, true, destPath, pfd, null); true }
                            8 -> { m.invoke(am, pid.toString(), -1, true, false, false, destPath, pfd, null); true }
                            else -> false
                        }
                    }.getOrDefault(false)
                }
                if (invoked) return destFile.exists() && destFile.length() > 0
            }
        } catch (e: Exception) {
            Log.w(TAG, "dumpHeap IPC failed for pid=$pid, falling back to exec", e)
        }
        // Fallback: am dumpheap (blocked on Samsung OneUI 8)
        return try {
            Runtime.getRuntime().exec(arrayOf("am", "dumpheap", pid.toString(), destPath))
                .waitFor() == 0
        } catch (_: Exception) { false }
    }

    override fun readLogcat(packageName: String?, maxLines: Int): String {
        val lines = maxLines.coerceIn(1, 10_000)
        return try {
            if (packageName.isNullOrBlank()) {
                // No filter: dump last N lines from the global log
                execOutput("logcat", "-d", "-t", lines.toString())
            } else {
                // Find PIDs for this package via 'ps', then filter logcat by pid
                val psOutput = execOutput("ps", "-A", "-o", "PID,NAME")
                val pids = psOutput.lines()
                    .drop(1) // skip "PID NAME" header
                    .filter { it.contains(packageName) }
                    .mapNotNull { it.trim().split("\\s+".toRegex()).firstOrNull()?.toIntOrNull() }

                if (pids.isEmpty()) {
                    // No running process — filter by package name substring in log lines
                    execOutput("logcat", "-d", "-t", lines.toString())
                        .lines()
                        .filter { it.contains(packageName) }
                        .takeLast(lines)
                        .joinToString("\n")
                } else {
                    val pidArgs = pids.flatMap { listOf("--pid=$it") }
                    val cmd = (listOf("logcat", "-d", "-t", lines.toString()) + pidArgs).toTypedArray()
                    execOutput(*cmd)
                }
            }
        } catch (_: Exception) { "" }
    }

    override fun getOpenFiles(pid: Int): List<String> {
        if (pid <= 0) return emptyList()
        // /proc/<pid>/fd/ contains one symlink per open fd pointing at the real path.
        // Shell can traverse this for any user process on all stock AOSP builds.
        val fdDir = File("/proc/$pid/fd")
        if (!fdDir.exists() || !fdDir.canRead()) return emptyList()
        return try {
            fdDir.listFiles()?.mapNotNull { fd ->
                try {
                    Files.readSymbolicLink(fd.toPath()).toString()
                        .takeIf { it.isNotBlank() && !it.startsWith("socket:") && !it.startsWith("anon_inode:") }
                } catch (_: Exception) { null }
            } ?: emptyList()
        } catch (_: Exception) { emptyList() }
    }

    override fun getExportedProviders(packageName: String?): List<String> {
        if (packageName.isNullOrBlank()) return emptyList()
        // Primary: IPackageManager.getPackageInfo with GET_PROVIDERS — direct Binder IPC
        try {
            val pi = Android17Compat.getPackageInfo(
                packageName, PackageManager.GET_PROVIDERS.toLong(), callingUserId()
            )
            if (pi != null) {
                val authorities = mutableListOf<String>()
                pi.providers?.forEach { provider ->
                    if (provider.exported) {
                        // authority can be comma-separated (multi-authority provider)
                        provider.authority?.split(";")?.forEach { auth ->
                            val trimmed = auth.trim()
                            if (trimmed.isNotEmpty()) authorities.add(trimmed)
                        }
                    }
                }
                return authorities.distinct()
            }
        } catch (e: Exception) {
            Log.w(TAG, "getExportedProviders IPC failed for $packageName, falling back", e)
        }
        // Fallback: pm dump (may be blocked on Samsung SELinux)
        val output = execOutput("pm", "dump", packageName)
        val authorities = mutableListOf<String>()
        var pendingExported = false
        for (line in output.lines()) {
            val t = line.trim()
            when {
                t.startsWith("ContentProviderRecord") -> pendingExported = false
                t == "exported=true" -> pendingExported = true
                pendingExported && t.startsWith("authority=") -> {
                    val auth = t.removePrefix("authority=").trim()
                    if (auth.isNotEmpty()) authorities.add(auth)
                    pendingExported = false
                }
            }
        }
        return authorities.distinct()
    }

    override fun callContentProvider(uri: String?, method: String?, arg: String?): Bundle {
        val result = Bundle()
        if (uri.isNullOrBlank() || !uri.startsWith("content://")) return result
        // Primary: direct IContentProvider.call() via Binder — no exec needed
        if (!method.isNullOrBlank()) {
            try {
                val authority = uri.removePrefix("content://").substringBefore("/").substringBefore("?")
                val provider = ActivityManagerApis.getContentProviderExternal(
                    authority, callingUserId(), null, "com.android.shell"
                )
                if (provider != null) {
                    return IContentProviderUtils.callCompat(
                        provider, "com.android.shell", authority, method, arg, null
                    ) ?: result
                }
            } catch (e: Exception) {
                Log.w(TAG, "callContentProvider IPC failed, falling back to exec", e)
            }
        }
        // Fallback: content call exec
        val cmd = mutableListOf("content", "call", "--uri", uri)
        if (!method.isNullOrBlank()) { cmd += listOf("--method", method) }
        if (!arg.isNullOrBlank()) { cmd += listOf("--arg", arg) }
        val output = execOutput(*cmd.toTypedArray())
        result.putString("raw", output)
        val inner = output.removePrefix("Bundle[{").removeSuffix("}]")
        for (pair in inner.split(", ")) {
            val eq = pair.indexOf('=')
            if (eq > 0) {
                result.putString(pair.substring(0, eq).trim(), pair.substring(eq + 1).trim())
            }
        }
        return result
    }

    override fun queryContentProvider(uri: String?, projection: String?): List<Bundle> {
        if (uri.isNullOrBlank() || !uri.startsWith("content://")) return emptyList()
        val cmd = mutableListOf("content", "query", "--uri", uri)
        if (!projection.isNullOrBlank()) { cmd += listOf("--projection", projection) }
        val output = execOutput(*cmd.toTypedArray())
        // Each row: "Row: N col1=val1, col2=val2, ..."
        return output.lines()
            .filter { it.trimStart().startsWith("Row:") }
            .map { row ->
                val bundle = Bundle()
                val content = row.substringAfter("Row:").trimStart().substringAfter(" ")
                for (pair in content.split(", ")) {
                    val eq = pair.indexOf('=')
                    if (eq > 0) {
                        bundle.putString(pair.substring(0, eq).trim(), pair.substring(eq + 1).trim())
                    }
                }
                bundle
            }
    }

    override fun getDumpsys(serviceName: String?): String {
        if (serviceName.isNullOrBlank()) return ""
        // Alphanumeric + underscore + dot only — no shell injection possible
        if (!serviceName.matches(Regex("[a-zA-Z0-9_.\\-]+"))) return ""
        return execOutput("dumpsys", serviceName)
    }

    override fun readProcFile(pid: Int, filename: String?): String {
        if (pid <= 0 || filename.isNullOrBlank()) return ""
        // Strict whitelist — we expose only files that are useful for inspection and
        // cannot be used for exploitation (no exe, environ, mem, etc.).
        val allowed = setOf(
            "maps", "status", "cmdline", "comm", "oom_score", "oom_adj",
            "smaps_rollup", "net/tcp", "net/tcp6", "net/unix", "net/udp6"
        )
        if (filename !in allowed) return ""
        return try {
            File("/proc/$pid/$filename").readText()
        } catch (_: Exception) { "" }
    }

    override fun getRunningAppPids(): Bundle {
        val bundle = Bundle()
        // Primary: IActivityManager.getRunningAppProcesses — no exec, works at shell UID
        try {
            val am = activityManagerService() ?: error("no activity service")
            val method = am.javaClass.methods.firstOrNull { it.name == "getRunningAppProcesses" }
                ?: error("getRunningAppProcesses not found")
            @Suppress("UNCHECKED_CAST")
            val procs = method.invoke(am) as? List<*>
            if (!procs.isNullOrEmpty()) {
                procs.forEach { p ->
                    if (p == null) return@forEach
                    try {
                        val name = p.javaClass.getField("processName").get(p) as? String ?: return@forEach
                        val pid = p.javaClass.getField("pid").get(p) as? Int ?: return@forEach
                        if (name.contains('.') && !name.startsWith('/')) bundle.putInt(name, pid)
                    } catch (_: Exception) {}
                }
                return bundle
            }
        } catch (e: Exception) {
            Log.w(TAG, "getRunningAppPids IPC failed, falling back to exec", e)
        }
        // Fallback: ps -A (may be blocked on Samsung SELinux)
        try {
            val output = execOutput("ps", "-A", "-o", "PID,NAME")
            for (line in output.lines().drop(1)) {
                val parts = line.trim().split("\\s+".toRegex(), 2)
                val pid = parts.getOrNull(0)?.toIntOrNull() ?: continue
                val name = parts.getOrNull(1) ?: continue
                if (name.contains('.') && !name.startsWith('/')) bundle.putInt(name, pid)
            }
        } catch (_: Exception) {}
        return bundle
    }
}
